(function($) {

    var TimeoutPopup = function(popuptItem, timeoutNumber) {

        var self = this;
        var timeoutMinutes = timeoutNumber * 3000;
        var getCookie = $.cookie('timeoutPopup');

        self.setPopupCookie = function() {

            $.cookie('timeoutPopup', {
                expires: 1,
                path: '/'
            });
        }

        self.openPopup = function() {

            if (getCookie) {
                return false;
            } else {
                self.setPopupCookie();
                $(popuptItem).removeClass('timeoutPopup_hidden');
            }
        }

        self.closePopupHandler = function() {

            $(popuptItem).on('click', function(event) {
                if ($(event.target).is(popuptItem) || $(event.target).is('.timeoutPopup__close')) {
                    $(popuptItem).addClass('timeoutPopup_hidden');
                } else {
                    return false;
                }

            });
        }

        self.timeoutEnd = function() {

            setTimeout(function() {
                self.openPopup();
            }, timeoutMinutes);
        }

        self.init = function() {

            if ($(popuptItem).length != 0) {
                self.timeoutEnd();
                self.closePopupHandler();
            } else {
                return false;
            }
        }

    }

    $(document).ready(function() {

        var openTimeoutPopup = new TimeoutPopup('#timeoutPopup', 1);
        openTimeoutPopup.init();

    });

})(jQuery);